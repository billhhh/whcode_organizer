#include <stdio.h>
#include <stdlib.h>


typedef int KeyType ;  
#define m 4                  
typedef struct Node{  
    int keynum;               
    struct Node *parent;       
    KeyType key[m+1];          
    struct Node *ptr[m+1];     
      
  }
NodeType;                    
  
typedef struct{  
    NodeType *pt;             
    int i;                                     
}
Result;                      
  


//����
int Search_B+Tree(NodeType *t,KeyType kx)  
{   
      p = t;
	  q = NULL;
	  found = FALSE;
	  i = 0; 

    while(p&&!found)  
    {  
		n = p->keynum;
		i = Search_B+Tree(p,kx);            
        if(i>0&&p->key[i] == kx)
			found = TRUE;   
        else {
			q = p;
			p = p->ptr[i];
		}  
    }  
    if(found) 
		return 1;                 
    else 
		return 0;                      
} 



//����
int Insert_B+Tree(NodeType **t,KeyType kx,NodeType *q,int i){   
       
      
    x = kx;
	ap = NULL;
	finished = FALSE;  
    while(q&&!finished)  
    {   
        Insert_B+Tree(q,i,x,ap);                 
        if(q->keynum < m)
			finished = TRUE;      
        else  
        {                                 
            s = m/2;
			split(q,ap);
			x = q->key[s];  
              
            q = q->parent;  
            if(q)
				i = Search_B+Tree(q,kx);   
        }  
    }  
    if(!finished)             
    NewRoot(t,q,x,ap);   
} 



//����
void split(NodeType *t ,int d){

    int i,j;
	if(d <= m-1)






}





//ɾ��
int delete_B+Tree(NodeTrpe *t,int i){






}
