package com.java.tree;

import java.util.Random;

public class Tree {
	public TreeNode root;
	public int number;
	public TreeNode head;
	public TreeNode getRoot() {
		return root;
	}
	public void setRoot(TreeNode root) {
		this.root = root;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public TreeNode getHead() {
		return head;
	}
	public void setHead(TreeNode head) {
		this.head = head;
	}
	
	public Object get(Comparable key){
		return root.get(key);
	}
	
    public Tree(int number){  
        if (number < 3) {  
            System.out.print("number must be greater than 2");  
            System.exit(0);  
        }  
        this.number = number;  
        root = new TreeNode(true, true);  
        head = root;  
    }  
      
    //����  
    public static void main(String[] args) {  
    	Tree tree = new Tree(6);  
        Random random = new Random();  
        long current = System.currentTimeMillis();  
        for (int j = 0; j < 100000; j++) {  
            for (int i = 0; i < 100; i++) {  
                int randomNumber = random.nextInt(1000);  
//                tree.insertOrUpdate(randomNumber, randomNumber);  
            }  
  
            for (int i = 0; i < 100; i++) {  
                int randomNumber = random.nextInt(1000);  
//                tree.remove(randomNumber);  
            }  
        }  
  
        long duration = System.currentTimeMillis() - current;  
        System.out.println("duration: " + duration);  
        int search = 80;  
        System.out.print(tree.get(search));
	
    }

}
