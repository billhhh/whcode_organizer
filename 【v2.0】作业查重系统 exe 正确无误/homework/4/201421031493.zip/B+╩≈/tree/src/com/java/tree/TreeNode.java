package com.java.tree;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

public class TreeNode {
	public boolean isLeaf;

	public boolean isRoot;

	public TreeNode parent;

	public TreeNode previous;

	public TreeNode next;

	public List<Entry<Comparable, Object>> entrys;
	public List<TreeNode> children;
	

	public boolean isLeaf() {
		return isLeaf;
	}

	public void setLeaf(boolean isLeaf) {
		this.isLeaf = isLeaf;
	}

	public boolean isRoot() {
		return isRoot;
	}

	public void setRoot(boolean isRoot) {
		this.isRoot = isRoot;
	}

	public TreeNode getParent() {
		return parent;
	}

	public void setParent(TreeNode parent) {
		this.parent = parent;
	}

	public TreeNode getPrevious() {
		return previous;
	}

	public void setPrevious(TreeNode previous) {
		this.previous = previous;
	}

	public TreeNode getNext() {
		return next;
	}

	public void setNext(TreeNode next) {
		this.next = next;
	}

	public List<Entry<Comparable, Object>> getEntrys() {
		return entrys;
	}

	public void setEntrys(List<Entry<Comparable, Object>> entrys) {
		this.entrys = entrys;
	}

	public List<TreeNode> getChildren() {
		return children;
	}

	public void setChildren(List<TreeNode> children) {
		this.children = children;
	}

	public TreeNode(boolean isLeaf) {
		this.isLeaf = isLeaf;
		entrys = new ArrayList<Entry<Comparable, Object>>();

		if (!isLeaf) {
			children = new ArrayList<TreeNode>();
		}
	}

	public TreeNode(boolean isLeaf, boolean isRoot) {
		this(isLeaf);
		this.isRoot = isRoot;
	}
	//search
	public Object get(Comparable key){
		  if (isLeaf) { 
	            for (Entry<Comparable, Object> entry : entrys) { 
	                if (entry.getKey().compareTo(key) == 0) { 
	                    //�����ҵ��Ķ��� 
	                    return entry.getValue(); 
	                } 
	            } 
	            //δ�ҵ���Ҫ��ѯ�Ķ��� 
	            return null; 
	             
	        //�������Ҷ�ӽڵ� 
	        }else { 
	            //���keyС�ڵ��ڽڵ�����ߵ�key���ص�һ���ӽڵ�������� 
	            if (key.compareTo(entrys.get(0).getKey()) <= 0) { 
	                return children.get(0).get(key); 
	            //���key���ڽڵ����ұߵ�key�������һ���ӽڵ�������� 
	            }else if (key.compareTo(entrys.get(entrys.size()-1).getKey()) >= 0) { 
	                return children.get(children.size()-1).get(key); 
	            //�����ر�key���ǰһ���ӽڵ�������� 
	            }else { 
	                for (int i = 0; i < entrys.size(); i++) { 
	                    if (entrys.get(i).getKey().compareTo(key) <= 0 && entrys.get(i+1).getKey().compareTo(key) > 0) { 
	                        return children.get(i).get(key); 
	                    } 
	                }    
	            } 
	        } 
	         
	        return null;
	}
	
	public void insertUpdate(Comparable key,Object obj,Tree tree){
		if(isLeaf){
			if(contains(key)||entrys.size()<tree.getNumber()){
				insertUpdate(key, obj,tree);
				if(parent!=null){
					parent.updateInsert(tree);
				}
				else{
					TreeNode left=new TreeNode(true);
					TreeNode right=new TreeNode(true);
					if(previous!=null){
						previous.setNext(left);
						left.setPrevious(previous);
					}
					if(next!=null){
						next.setPrevious(right);
						right.setNext(next);
					}
					if(previous==null){
						tree.setHead(left);
					}
					left.setNext(right);
					right.setPrevious(left);
					
				}
			}
		}
	}
	
	public  void updateInsert(Tree tree) {
		
		
	}

	public boolean contains(Comparable key){
		for(Entry<Comparable, Object>entry:entrys){
			if(entry.getKey().compareTo(key)==0){
				return true;
			}
		}
		return false;
	}
	

}
