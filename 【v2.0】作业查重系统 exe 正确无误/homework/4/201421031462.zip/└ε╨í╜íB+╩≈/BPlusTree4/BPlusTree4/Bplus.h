#ifndef BPLUS_H
#define BPLUS_H
#define nm 4
typedef int value;
class BPlusTree
{
public:
    struct BPNode {
        int numOfkeys;                     
        BPNode* father;       
        value keys[nm+1];                
        BPNode* children[nm+1];     
    };
    struct Result {
        BPNode* foundNode;            
        int        position;          
        bool       hasFound;        
    };
     BPNode*  root;         
    int    maxNum;           
    int    minNum;   
    BPlusTree();
    virtual ~BPlusTree();
    Result searchBPTree(value v);   
	Result findValue(BPNode*, value);  
    bool insert(value);            
    bool remove(value);         
    static BPNode* createLeaf() ;       
    bool insertLargeValue(value);           
    bool insertInNode(BPNode*, int, value);  
	  void deleteAdjust(BPNode*&);             
    void split(BPNode*&); 
    bool deleteInNode(BPNode*, int);         
    void adjustNode(BPNode*);              
    void check(BPNode*);                           
    void printNode(BPNode*) const;                    
    void printTree() const;  
     void destroy(BPNode* node); 
};

#endif 
