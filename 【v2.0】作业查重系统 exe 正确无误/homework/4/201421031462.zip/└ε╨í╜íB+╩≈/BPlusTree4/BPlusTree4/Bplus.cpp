#include "Bplus.h"
#include <math.h>
#include <assert.h>
#include <stdio.h>
#include <iostream>
using namespace std;

BPlusTree::BPlusTree()
{   root=NULL;
    minNum = ceil((float)(nm)/2);     
    maxNum = nm;                     
}
BPlusTree::~BPlusTree()
{
    if(root) {
        destroy(root);
    }
}
void BPlusTree::destroy(BPNode* node) {
    if(node->numOfkeys == 0) {
        delete node;
        return;
    }
    for(int i = 0; i < node->numOfkeys; i++) {
        destroy(node->children[i]);
    }
    delete node;
}

BPlusTree::Result BPlusTree::findValue(BPNode* node, value v) {//�ڽڵ��в���λ��
    int i, pos = -1;    
    bool res = false;   
   // assert(node && "The node is an empty pointer!!");
    
    for(i = 0; i < node->numOfkeys; i++) {//�ڽڵ��в���ʱ��ֵ�϶�����������ֵ
        if(node->keys[i] >= v) {
            pos = i;
           
            if(node->keys[i] == v)//���ֵ��ȣ�����ΪҶ��ʱ�����Ѿ��ҵ�
                res = true;
            break;
        }
    }
    if(!node->children[0]) 
	{
		Result rs;
		rs.foundNode=node;
		rs.position=pos;
		rs.hasFound=res;
		return rs;
	}
    return findValue(node->children[pos], v);//ֵС�ڹؼ��ֻ���ֵ��ȵ��ǲ���Ҷ�ӣ���Ҫ��������ȥ��
}
BPlusTree::Result BPlusTree::searchBPTree(value v) {
	Result rs;
    if(!root)//���Ϊ������û�и�ֵ
	{   rs.foundNode=NULL;
	rs.position=-1;
	rs.hasFound=false;
		return rs;
	}
    if(v > root->keys[root->numOfkeys-1]) //���ֵ���ڹؼ����У�root�У������ֵ�򽫽ڵ�ָ��ָ��root
	{Result rs;
	rs.foundNode=root;
	rs.position=-1;
	rs.hasFound=false;
	return rs;// represent v is larger than the max
	}
    return findValue(root, v);//��ʱ��ʾֵС�����ֵ����ӽڵ��в���λ��
}



BPlusTree::BPNode* BPlusTree::createLeaf() {//����Ҷ�ӽڵ�
    BPNode* p = new BPNode;
    p->numOfkeys = 0;
    for(int i = 0; i < nm+1; i++) p->children[i] = NULL;
    return p;
}
bool BPlusTree::insert(value v) {
    if(!root) {//����ǿο�����ֱ�ӽ�Ҷ�ӽڵ㸳����ֵ
        root = createLeaf();
        root->keys[0] = v;
        root->father = NULL;
        root->numOfkeys = 1;
        return true;
    }

    Result res = searchBPTree(v);//���ҵ�ֵ�����е�λ��
    if(res.hasFound) 
		return false;//���ֵ�Ѿ����ڣ�����false����Ӧ���ҵ�ֵ�������Ҷ�ӵĽڵ㣩
  
    if(res.foundNode == root && res.position == -1) 
		return insertLargeValue(v);//�ҵ��Ľڵ���root�Ҳ���root�ڵ��б�������ֵ�����ֵ
    return insertInNode(res.foundNode, res.position, v);//���ҵ��Ľڵ��λ���в���
}
bool BPlusTree::insertLargeValue(value v) {
    BPNode* node = root;
    while(node->children[0]) {
        node->keys[node->numOfkeys-1] = v;
        node = node->children[node->numOfkeys-1];

    }
    node->keys[node->numOfkeys] = v;
    node->children[node->numOfkeys] = NULL;
    node->numOfkeys++;
    adjustNode(node);
    return true;
}

bool BPlusTree::insertInNode(BPNode* node, int pos, value v) {
  
    for(int i = node->numOfkeys; i > pos; i--) {
        node->keys[i] = node->keys[i-1];
    }
    node->keys[pos] = v;   
    node->numOfkeys++;      
    if(node->numOfkeys > maxNum)//�ؼ��ֵĸ������ڽ���������BP��Ҫ����
        adjustNode(node);
    return true;
}



void BPlusTree::check(BPNode* node) {//������ֵ�Ƿ�����
   
    if(node == root) return;
    BPNode* father = node->father;
    int i;
   
    for(i = 0; i < father->numOfkeys; i++) {
        if(father->children[i] == node) break;
    }
   
    if(node->keys[node->numOfkeys-1] == father->keys[i]) return;
   
    else if(node->keys[node->numOfkeys-1] < father->keys[i]) {
        father->keys[i] = node->keys[node->numOfkeys-1] ;
    }
  
    if(i == father->numOfkeys - 1) 
		check(father);
}
bool BPlusTree::remove(value v) {//ɾ������ֵ
    Result res = searchBPTree(v);
  
    if(!res.hasFound || !res.foundNode) {
        cout<<v<<" is not be found!"<<endl;
        return false;
    }
    return deleteInNode(res.foundNode, res.position);
}
bool BPlusTree::deleteInNode(BPNode* node, int pos) {
    
    for(int i = pos; i < node->numOfkeys-1; i++) {//������еĹؼ�����ǰ�ƶ���ɾ��������ֵ
        node->keys[i] = node->keys[i+1];
    }
    node->numOfkeys--;

   
    if(node->numOfkeys >= minNum) {
        
        if(pos== node->numOfkeys)
            check(node);
    } else //������ؼ��ָ���С��minNum��������B+������Ҫ���е���
        adjustNode(node);
    return true;
}



void BPlusTree::deleteAdjust(BPNode* &node) {//ɾ��ĳ������ֵ�ǿ���Ҫ�������ߺϲ�
  
    if(!node) return;
 
    if(node == root) {
   
        if(node->numOfkeys == 0) {
            delete root;
            root = NULL;
        }
     
        if(node->children[0] == NULL) return;
      
        if(node->numOfkeys = 1) {
            root = node->children[0];
            root->father = NULL;
            delete node;
            node = root;
        }
        return;
    }
    BPNode* father = node->father;
    BPNode* Lnode, *Rnode;
    int i;
   
    for(i = 0; i < father->numOfkeys; i++) {//�ҵ�node��λ��
        if(father->children[i] == node) break;
    }
    if(i == 0) {
        Lnode = NULL;
        Rnode = father->children[i+1];
    } else if(i == father->numOfkeys - 1) {
        Rnode = NULL;
        Lnode = father->children[i-1];
    } else {
        Lnode = father->children[i-1];
        Rnode = father->children[i+1];
    }
   
    if(Rnode && Rnode->numOfkeys > minNum) {//�ֵܹ���������ֵܽ�
        node->numOfkeys++;
        node->keys[node->numOfkeys-1] = Rnode->keys[0];
        node->children[node->numOfkeys-1] = Rnode->children[0];
      
        if(node->children[0])
            node->children[node->numOfkeys - 1]->father = node;
      
        father->keys[i] = node->keys[node->numOfkeys-1];
      
        if(i == father->numOfkeys - 1) check(father);
      
        for(int j = 0; j < Rnode->numOfkeys - 1; j++ ) {
            Rnode->keys[j] = Rnode->keys[j+1];
            Rnode->children[j] = Rnode->children[j+1];
        }
        Rnode->numOfkeys--;

        return;
    }
 
    if(Lnode && Lnode->numOfkeys > minNum) {//�����ֵ��н�
      
        for(int j = node->numOfkeys; j > 0; j--) {
            node->keys[j] = node->keys[j-1];
            node->children[j] = node->children[j-1];
        }
        node->numOfkeys++;
     
        node->keys[0] = Lnode->keys[Lnode->numOfkeys-1];//�������н�
        node->children[0] = Lnode->children[Lnode->numOfkeys-1];
      
        if(node->children[0]) node->children[0]->father = node;
        Lnode->numOfkeys--;
      
        father->keys[i-1] = Lnode->keys[Lnode->numOfkeys-1];
      
        if(node->keys[node->numOfkeys-1] < father->keys[i]) {
            father->keys[i] = node->keys[node->numOfkeys-1];
         
            if(i == father->numOfkeys - 1) check(father);
        }
        return;
    }
    int leftPosInfather; 
    BPNode* L, *R;  
    if(Rnode) {
        L = node;
        R = Rnode;
        leftPosInfather = i;
    } else if(Lnode) {
        L = Lnode;
        R = node;
        leftPosInfather = i - 1;
    } 
  
    for(int j = 0; j < R->numOfkeys; j++) {//���ҽڵ�ϲ��������У�ɾ���ҽ��
        L->keys[L->numOfkeys+j] = R->keys[j];
        L->children[L->numOfkeys+j] = R->children[j];
    }

  
    if(L->children[0]) {
        for(int j = 0; j < R->numOfkeys; j++) {
            L->children[L->numOfkeys+j]->father = L;
        }
    }
    L->numOfkeys += R->numOfkeys;
    delete R;
   
    for(int j = leftPosInfather+1; j < father->numOfkeys-1; j++) {
        father->keys[j] = father->keys[j+1];
        father->children[j] = father->children[j+1];
    }
    father->keys[leftPosInfather] = L->keys[L->numOfkeys-1];
    father->numOfkeys--;
   
    if(leftPosInfather == father->numOfkeys - 1) check(father);
  
    node = L;
}
void BPlusTree::adjustNode(BPNode* node) {//��㲻����B+������Ҫ���е���
    if(!node) return;
    if(node->numOfkeys < minNum ) {
        bool isRoot = node == root;
        deleteAdjust(node);
        if(!isRoot)
            adjustNode(node->father);
        return;
    }
    if(node->numOfkeys > maxNum) {
        split(node);
        adjustNode(node->father);
        return;
    }
}
void BPlusTree::split(BPNode* &node) {//����
  
	int leftNum = ceil((float)(nm+1)/2);
    int rightNum = node->numOfkeys -  leftNum;
    BPNode* rightNode = createLeaf();//�����µĽ��Ϊ�ҽ��
  
    for(int i = 0; i < rightNum; i++) {
        rightNode->keys[i] = node->keys[leftNum+i];
        rightNode->children[i] = node->children[leftNum+i];
    }
  
    if(rightNode->children[0]) {//����ҽ�㲻��Ҷ�ӽ�㣬��Ҫ�����ǵĺ���ָ����
        for(int i = 0; i < rightNum; i++)
            rightNode->children[i]->father = rightNode;
    }
    rightNode->numOfkeys = rightNum;
    node->numOfkeys = leftNum;
    if(node == root) {
        root = createLeaf();
        root->numOfkeys=2;
        root->keys[0] = node->keys[node->numOfkeys-1];
        root->keys[1] = rightNode->keys[rightNode->numOfkeys-1];
        root->children[0] = node;
        root->children[1] = rightNode;
        node->father = rightNode->father = root;
        root->father=NULL;
        return;
    }
    int pos;
    BPNode* father = node->father;
   
    for(pos = 0; pos < father->numOfkeys; pos++) {//�ҵ�����ڸ�����е�λ��
        if(father->children[pos] == node) break;
    }
    for(int j = father->numOfkeys; j > pos; j--) {
        father->keys[j] = father->keys[j-1];
        father->children[j] = father->children[j-1];
    }
    father->numOfkeys++;
    father->children[pos+1] = rightNode;
    father->keys[pos] = node->keys[node->numOfkeys-1];
    rightNode->father = father;
    return;

}

void BPlusTree::printTree() const {
    if(root) printNode(root);
    else
        cout<<"B+ Tree is empty!!!!"<<endl;
}
void BPlusTree::printNode(BPNode* node) const{
    if(!node) return;
    cout<<"Node : ";
    for(int i = 0; i < node->numOfkeys; i++) {
        cout<<node->keys[i]<<", ";
    }
    if(node->father) {
		int i=0;
        cout<<"<------ Node : ";
			while (i<node->father->numOfkeys)
			{
				cout<<node->father->keys[i]<<",";
				i++;
			}
    }
    cout<<endl;
    for(int i = 0; i < node->numOfkeys; i++) {
        printNode(node->children[i]);
    }
}








