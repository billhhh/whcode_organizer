﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BPTree
{
    public class BPTree
    {
        public Node root{ get; set; } //根节点
        public int order { get; set; } //阶数
        public Node leafHead { get; set; } //叶子节点的链表头

        public BPTree(int order)
        {
            if (order < 3)
                return;
            this.order = order;
            root = new Node(true, true);
            leafHead = root;
        }

        public string getValue(int key)
        {
            return root.getValue(key);
        }

        public void insertOrUpdate(int key, string value)
        {
            root.insertOrUpdate(key, value);
        }

        public void remove(int key)
        {
            return;
        }
    }
}
