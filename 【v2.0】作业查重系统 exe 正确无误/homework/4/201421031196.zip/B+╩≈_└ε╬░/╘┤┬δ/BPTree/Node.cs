﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BPTree
{
    public class Node
    {
        public bool isLeaf { get; set; }   //是否为叶子节点
        public bool isRoot { get; set; }   //是否是根节点
        public Node parent { get; set; }   //父亲节点
        public Node leafPrevious { get; set; }  //叶子节点的前节点
        public Node leafNext { get; set; } //叶子节点的后节点
        public List<KeyValuePair<int,string>> keyValueList { get; set; } //节点的keyValue集合
        public List<Node> childrenList { get; set; } //节点的子节点集合

        public Node(bool isLeaf)
        {
            this.isLeaf = isLeaf;
            keyValueList = new List<KeyValuePair<int, string>>();
            if (!isLeaf)
            {
                childrenList = new List<Node>();
            }
        }

        public Node(bool isLeaf,bool isRoot)
        {
            this.isLeaf = isLeaf;
            keyValueList = new List<KeyValuePair<int, string>>();
            if (!isLeaf)
            {
                childrenList = new List<Node>();
            }

            this.isRoot = isRoot;
        }

        public string getValue(int key)
        {
            //如果节点是叶子节点
            if (isLeaf)
            {
                //在该节点的keyValueList中需找对应的key值，若存在，则返回其value；若不存在，则返回Null
                for (int i = 0; i < keyValueList.Count; i++)
                {
                    if (keyValueList[i].Key == key)
                        return keyValueList[i].Value;
                }
                return null;
            }
            //如果节点为非叶子节点
            else 
            { 
                //如果key值小于等于节点最左边的Key值，则从第一个子节点搜索
                if (key <= keyValueList[0].Key)
                {
                    return childrenList[0].getValue(key);
                }
                //如果key值大于节点最右边的Key值，则从第最后一个子节点搜索
                else if (key >= keyValueList[keyValueList.Count - 1].Key)
                {
                    return childrenList[childrenList.Count - 1].getValue(key);

                }
                else
                {
                    for (int i = 0; i < keyValueList.Count; i++)
                    {
                        if (key >= keyValueList[i].Key && key < keyValueList[i + 1].Key)
                        {
                            return childrenList[i].getValue(key);
                        }
                    }
                }
 
            }
            return null;
        }

        //对某棵B+树插入(或更新)节点
        public void insertOrUpdate(int key, string value, BPTree tree)
        {
            //如果是叶子节点
            if (isLeaf)
            {
                //有足够的空间，不需要分类，则直接插入或更新
                if (keyValueList.Count < tree.order || (keyValueList.Where(ee => ee.Key == key) != null))
                {
                    insertOrUpdate(key, value);
                    if (parent != null)
                    {
                        //更新父节点
                        parent.updateInsert(tree);
                    }
                }
                //需要分裂
                else
                {
                    //分裂成左右两个节点 
                    Node left = new Node(true);
                    Node right = new Node(true);
                    //设置链接 
                    if (leafPrevious != null)
                    {
                        leafPrevious.leafNext = left;
                        left.leafPrevious = leafPrevious;
                    }
                    if (leafNext != null)
                    {
                        leafNext.leafPrevious = right;
                        right.leafNext = leafNext;
                    }
                    if (leafPrevious == null)
                    {
                        tree.leafHead = left;
                    }

                    left.leafNext = right;
                    right.leafPrevious = left;
                    leafPrevious = null;
                    leafNext = null;

                    //左右两节点关键字长度
                    int leftSize = (tree.order + 1) / 2 + (tree.order + 1) % 2;
                    int rightSize = (tree.order + 1) / 2;

                    //复制子节点到分裂出来的新节点，并更新关键字
                    insertOrUpdate(key, value);
                    for (int i = 0; i < leftSize; i++)
                    {
                        left.keyValueList.Add(keyValueList[i]);
                    }
                    for (int i = 0; i < rightSize; i++)
                    {
                        right.keyValueList.Add(keyValueList[leftSize + i]);
                    }

                    //如果不是根节点
                    if (parent != null)
                    {
                        //调整父子关系
                        int index = parent.childrenList.IndexOf(this);
                        parent.childrenList.Remove(this);
                        left.parent = parent;
                        right.parent = parent;
                        parent.childrenList.Insert(index, left);
                        parent.childrenList.Insert(index + 1, right);
                        keyValueList = null;
                        childrenList = null;
                        //父节点更新关键字
                        parent.updateInsert(tree);
                        parent = null;
                    }
                    //如果是根节点
                    else
                    {
                        isRoot = false;
                        parent = new Node(false, true);
                        tree.root = parent;
                        left.parent = parent;
                        right.parent = parent;
                        parent.childrenList.Add(left);
                        parent.childrenList.Add(right);
                        keyValueList = null;
                        childrenList = null;
                        //父节点更新关键字
                        parent.updateInsert(tree);

                    }
                }

            }
            //如果不是叶子节点
            else
            {
                if (key <= keyValueList[0].Key)
                {
                    childrenList[0].insertOrUpdate(key, value, tree);
                }
                else if (key >= keyValueList[keyValueList.Count - 1].Key)
                {
                    childrenList[keyValueList.Count - 1].insertOrUpdate(key, value, tree);
                }
                else
                {
                    for (int i = 0; i < keyValueList.Count; i++)
                    {
                        if (key >= keyValueList[i].Key && key < keyValueList[i + 1].Key)
                        {
                            childrenList[i].insertOrUpdate(key, value, tree);
                            break;
                        }
                    }
                }
 
            }
 
        }

        //对当前节点进行插入或更新（有足够空间，无需分裂调整）
        public void insertOrUpdate(int key, string value)
        {
            var keyValue = new KeyValuePair<int, string>(key,value);
            for (int i = 0; i < keyValueList.Count; i++)
            {
                //如果该关键字已存在，则更新
                if (key == keyValueList[i].Key)
                {
                    keyValueList.RemoveAt(i);
                    keyValueList.Add(keyValue);
                    keyValueList = keyValueList.OrderBy(ee => ee.Key).ToList();
                    return;
                }
            }

            //否则直接插入
            keyValueList.Add(keyValue);
            keyValueList = keyValueList.OrderBy(ee => ee.Key).ToList();

        }

        //插入后对中间节点的更新
        public void updateInsert(BPTree tree)
        {
            validate(this, tree);

            //如果子节点数超出阶数，则需要分裂该节点
            if (childrenList.Count > tree.order)
            {
                Node left = new Node(false);
                Node right = new Node(false);

                //左右两节点关键字长度
                int leftSize = (tree.order + 1) / 2 + (tree.order + 1) % 2;
                int rightSize = (tree.order + 1) / 2;

                //复制子节点到分裂出来的新节点，并更新关键字
                for (int i = 0; i < leftSize; i++)
                {
                    left.childrenList.Add(childrenList[i]);
                    left.keyValueList.Add(new KeyValuePair<int, string>(childrenList[i].keyValueList[0].Key, null));
                    childrenList[i].parent = left;
                }
                for (int i = 0; i < rightSize; i++)
                {
                    right.childrenList.Add(childrenList[leftSize+i]);
                    right.keyValueList.Add(new KeyValuePair<int, string>(childrenList[leftSize+i].keyValueList[0].Key, null));
                    childrenList[leftSize+i].parent = left;
                }

                //如果不是根节点
                if (parent != null)
                {
                    //调整父子关系
                    int index = parent.childrenList.IndexOf(this);
                    parent.childrenList.Remove(this);
                    left.parent = parent;
                    right.parent = parent;
                    parent.childrenList.Insert(index, left);
                    parent.childrenList.Insert(index + 1, right);
                    keyValueList = null;
                    childrenList = null;
                    //父节点更新关键字
                    parent.updateInsert(tree);
                    parent = null;
                }
                //如果是根节点
                else 
                {
                    isRoot = false;
                    parent = new Node(false, true);
                    tree.root = parent;
                    left.parent = parent;
                    right.parent = parent;
                    parent.childrenList.Add(left);
                    parent.childrenList.Add(right);
                    keyValueList = null;
                    childrenList = null;
                    //父节点更新关键字
                    parent.updateInsert(tree);

                }
                
            }

            
           

 
        }

        //调整节点关键字
        public void validate(Node node, BPTree tree)
        {
            //如果关键字个数和子节点个数相同
            if (node.keyValueList.Count == node.childrenList.Count)
            {
                for (int i = 0; i < node.keyValueList.Count; i++)
                {
                    int key = node.childrenList[i].keyValueList[0].Key;
                    if (node.keyValueList[i].Key != key)
                    {
                        node.keyValueList.RemoveAt(i);
                        node.keyValueList.Insert(i, new KeyValuePair<int, string>(key, null));
                        if (!node.isRoot)
                        {
                            validate(node.parent, tree);
                        }
                    }
                }
            }
            //如果子节点数不等于关键字个数但仍大于等于M / 2并且小于等于M，并且大于等于2 
            else if ((node.isRoot && node.childrenList.Count >= 2) || (node.childrenList.Count >= tree.order / 2 && node.childrenList.Count <= tree.order && node.childrenList.Count >= 2))
            {
                node.keyValueList.Clear();
                for (int i = 0; i < node.childrenList.Count; i++)
                {
                    int key = node.childrenList[i].keyValueList[0].Key;
                    node.keyValueList.Add(new KeyValuePair<int, string>(key, null));
                    if (!node.isRoot)
                    {
                        validate(node.parent, tree);
                    }
                }
 
            }

            
 
        }


    }
}
