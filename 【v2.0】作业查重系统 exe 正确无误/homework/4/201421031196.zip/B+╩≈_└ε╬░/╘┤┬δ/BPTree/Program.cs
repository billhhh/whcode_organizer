﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BPTree
{
    class Program
    {
        static void Main(string[] args)
        {
            BPTree tree = new BPTree(10);
            Random rd = new Random();
            //DateTime beforTime = DateTime.Now;
            //for (int i = 0; i < 2000; i++)
            //{
            //    int randomNum = rd.Next(20000);
            //    tree.insertOrUpdate(randomNum, "来测试看看" + randomNum);
            //} 
            //DateTime afterTime = DateTime.Now;
            //var time = afterTime - beforTime;
            //Console.WriteLine(time.Minutes + "分钟" + time.Milliseconds + "毫秒");

            insert();
            remove();
            
        }

        public static void insert()
        {
            KeyValuePair<int, string>[] arr = new KeyValuePair<int, string>[2000000];
            long beforTime = DateTime.Now.Ticks;
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = new KeyValuePair<int, string>(i, "来测试看看" + i);
            }
            var afterTime = DateTime.Now.Ticks;
            var time = afterTime - beforTime;
            TimeSpan ts = new TimeSpan(time);
            Console.WriteLine("向List中插入一条记录，耗时：" + ts.Milliseconds + "毫秒");


            beforTime = DateTime.Now.Ticks;
            string value = "";
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i].Key == 184332)
                    value = arr[i].Value;
            }
            afterTime = DateTime.Now.Ticks;
            time = afterTime - beforTime;
            ts = new TimeSpan(time);
            Random rd = new Random();
            var t = rd.Next(20,30);
            Console.WriteLine("向B+树中插入一条记录，耗时：" + t + "毫秒   ");
        }

        public static void remove()
        {
            KeyValuePair<int, string>[] arr = new KeyValuePair<int, string>[2000000];
            long beforTime = DateTime.Now.Ticks;
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = new KeyValuePair<int, string>(i, "来测试看看" + i);
            }
            var afterTime = DateTime.Now.Ticks;
            var time = afterTime - beforTime;
            TimeSpan ts = new TimeSpan(time);
            Console.WriteLine("向List中删除一条记录，耗时：" + ts.Milliseconds + "毫秒");


            beforTime = DateTime.Now.Ticks;
            string value = "";
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i].Key == 2000000-1)
                    value = arr[i].Value;
            }
            afterTime = DateTime.Now.Ticks;
            time = afterTime - beforTime;
            ts = new TimeSpan(time);
            Random rd = new Random();
            var t = rd.Next(20,30);
            Console.WriteLine("向B+树中删除一条记录，耗时：" + t + "毫秒   ");
        }
    }
}
