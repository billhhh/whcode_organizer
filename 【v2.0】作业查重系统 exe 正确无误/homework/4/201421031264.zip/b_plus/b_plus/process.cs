﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace b_plus
{
    public  class process : data
    {
        int flag=0;

        #region 初始化树

        public BTreeNode Create_BTree(int key)
        {
            BTreeNode root;
            root = new BTreeNode();
            root.isleaf = false;
            for (int i = 0; i < MINNUM_CHILD; i++)
                root.succeedingnode[i] = new BTreeNode();
            root.parentnode = null;
            root.nsize = 0;
            InsertBTree(root, key);
            return root;
        }

        public int middleNode(BTreeNode p, int key)
        {
            int c = p.nsize;
            int[] tmp = new int[c + 1];
            bool flag = false;
            int j = c;
            for (int i = c - 1; i >= 0 && j >= 0; i--)
            {
                if (p.key[i] > key)
                {
                    tmp[j--] = p.key[i];
                }
                else if (p.key[i] <= key && flag == false)
                {
                    tmp[j--] = key;
                    tmp[j--] = p.key[i];
                    flag = true;
                }
                else
                {
                    tmp[j--] = p.key[i];
                }
            }
            return tmp[(c + 1) / 2];
        }

        public BTreeNode createNode()
        {
            BTreeNode p = new BTreeNode();
            return p;
        }

        #endregion

        #region 查询

        public BTreeNode selectKey(BTreeNode root, int key)
        {
            BTreeNode p = root;
            BTreeNode result = null;
            int i;

            if (p.isleaf)
            {
                int c = p.nsize;
                for (i = 0; i < c; i++)
                {
                    if (p.key[i] == key)
                    {
                        result = p.succeedingnode[i];
                        break;
                    }

                }
            }
            else
            {
                int c = p.nsize;
                for (i = 0; i < c; i++)
                {
                    if (p.key[i] == key)
                    {
                        result = selectKey(p.succeedingnode[i + 1], key);
                        break;
                    }
                    else if (p.key[i] > key)
                    {
                        result = selectKey(p.succeedingnode[i], key);
                        break;
                    }
                }
            }
            return result;
        }

        #endregion

        #region 插入
        //向下插入
        public bool InsertBTree(BTreeNode startnode, int key)
        {
            BTreeNode p = new BTreeNode();
            bool state = false;
            startnode.nodetype = flag;

            if (startnode == null)
            {
                return state;
            }

            p = startnode;
            int c = p.nsize;
            int i;

            if (p.isleaf)//叶子节点
            {
                //节点未满,则插入
                if (c < MAXNUM_LEAF)
                {
                    for (i = c; i >= 0; i--)
                    {
                        if (p.key[i] > key)
                            p.key[i + 1] = p.key[i];
                        else
                            break;
                    }
                    p.key[i] = key;
                    p.nsize++;
                    state = true;
                }
                //节点满，则分裂节点
                else
                {
                    splitNode(p, key);
                }
            }
            else	//内节点
            {
                flag++;
                //找到key的查找分支
                for (i = 0; i < c; i++)
                {
                    if (p.key[i] > key)
                        break;
                }

                if (flag == 2)
                {
                    p.succeedingnode[i] = new BTreeNode();
                    p.succeedingnode[i].isleaf = true;
                    flag = 0;
                }
                //顺着分支执行插入
                if (i < c)
                    state = InsertBTree(p.succeedingnode[i], key);
                else
                    state = InsertBTree(p.succeedingnode[c], key);
            }
            return state;
        }

        //向上插入
        public bool Insert_BTree2(BTreeNode startnode, int key, BTreeNode oldnode, BTreeNode newnode)
        {
            BTreeNode p = startnode;
            bool state = false;
            int i;
            if (p.nodetype == 0 || p.nodetype == 1)
            {
                int c = p.nsize;
                if (p.nsize < c - 1)
                {
                    for (i = c - 1; i >= 0; i--)
                    {
                        if (p.key[i] > key)
                            p.key[i + 1] = p.key[i];
                        else
                        {
                            break;
                        }
                    }
                    p.key[i] = key;
                    p.succeedingnode[i] = oldnode;
                    p.succeedingnode[i + 1] = newnode;
                    p.nsize += 1;
                    state = true;
                }
                else
                {
                    for (i = 0; i < c; i++)
                    {
                        if (p.key[i] > key)
                            break;
                    }
                    state = splitInterNode(p, newnode, i, key);
                }
            }
            return state;
        }

        #endregion

        #region 分裂

        public bool splitNode(BTreeNode p, int key)
        {
            bool state = false;
            int midKey;
            if (p != null)
            {
                if (p.isleaf)
                {
                    int c = p.nsize;
                    int i;
                    for (i = 0; i < c; i++)
                        if (p.key[i] >= key)
                            break;
                    int mid = (c + 1) / 2;
                    //构建新的子树节点
                    BTreeNode node = createNode();

                    if (i < mid)//插入的关键字存在左子树
                    {
                        int j;
                        for (j = mid - 2; j >= 0; j--)
                        {
                            if (p.key[j] > key)
                            {
                                p.key[j + 1] = p.key[j];
                            }
                            else
                                break;
                        }
                        p.key[j] = key;
                        //暂不考虑关键字对应的记录的存放位置。

                        //将剩余的节点复制到新节点中。
                        for (j = mid - 1; j < c; j++)
                        {
                            node.key[j - mid] = p.key[j];
                            p.key[j] = 0;
                        }
                        node.nsize = c - mid + 1;
                        node.nodetype = p.nodetype;
                        node.isleaf = p.isleaf;
                        midKey = middleNode(p, key);
                        if (p.parentnode == null)
                        {

                            BTreeNode parentNode = createNode();
                            parentNode.key[0] = midKey;
                            parentNode.isleaf = false;
                            parentNode.nodetype = 0;//根节点
                            parentNode.nsize = 1;
                            parentNode.parentnode = null;
                            p.parentnode = node.parentnode = parentNode;
                            parentNode.succeedingnode[0] = p;
                            parentNode.succeedingnode[1] = node;
                        }
                        else
                        {
                            node.parentnode = p.parentnode;
                            Insert_BTree2(p.parentnode, midKey, p, node);
                        }
                    }
                    else//插入右子树
                    {
                        int j, pos;
                        pos = 0;
                        bool flag = false;//是否添加
                        for (j = mid; j < c; j++)
                        {
                            if (p.key[j] < key)
                            {
                                node.key[pos++] = p.key[j];
                            }
                            else if (p.key[j] >= key && flag == false)
                            {
                                node.key[pos++] = key;
                                node.key[pos++] = p.key[j];
                                flag = true;
                            }
                            else
                            {
                                node.key[pos++] = p.key[j];
                            }
                            p.key[j] = 0;
                        }
                        node.nsize = c - mid + 1;
                        node.parentnode = p.parentnode;
                        node.nodetype = p.nodetype;
                        node.isleaf = p.isleaf;

                    }
                    midKey = middleNode(p, key);
                    if (p.parentnode == null)
                    {
                        BTreeNode parentNode = createNode();
                        parentNode.key[0] = midKey;
                        parentNode.isleaf = false;
                        parentNode.nodetype = 0;//根节点
                        parentNode.nsize = 1;
                        parentNode.parentnode = null;
                        p.parentnode = node.parentnode = parentNode;
                        parentNode.succeedingnode[0] = p;
                        parentNode.succeedingnode[1] = node;
                    }
                    else
                    {
                        node.parentnode = p.parentnode;
                        Insert_BTree2(p.parentnode, midKey, p, node);
                    }
                    state = true;
                }
            }
            return state;
        }

        //分裂内部节点
        public bool splitInterNode(BTreeNode internode, BTreeNode succeedingnode, int splitpos, int key)
        {
            bool state = false;
            BTreeNode p = internode;
            if (p != null)
            {
                //存在父节点
                BTreeNode node = new BTreeNode();
                int c = p.nsize; 
                for (int i = 0; i < c; i++)
                    if (p.key[i] >= key)
                        break;
                //构建新的子树节点
                node = createNode();
                if (splitpos > 0 && splitpos < c)
                {
                    node.succeedingnode[0] = succeedingnode;
                    for (int i = splitpos; i < c; i++)
                    {
                        node.key[i - splitpos] = p.key[i];
                        node.succeedingnode[i - splitpos + 1] = p.succeedingnode[i + 1];
                        p.key[i] = 0;
                        p.succeedingnode[i + 1] = null;
                    }
                    node.nsize = c - splitpos;
                    node.isleaf = p.isleaf;
                    node.nodetype = p.nodetype;
                    node.parentnode = p.parentnode;
                    p.nsize = splitpos;

                    if (p.nodetype == 0)
                    {
                        BTreeNode newroot = new BTreeNode();
                        newroot.key[0] = key;
                        newroot.nsize = 1;
                        newroot.nodetype = 0;
                        newroot.isleaf = false;
                        newroot.succeedingnode[0] = p;
                        newroot.succeedingnode[1] = node;
                        p.nodetype = node.nodetype = 1;
                        p.parentnode = node.parentnode = newroot;
                        state = true;
                    }
                    else
                        state = Insert_BTree2(p.parentnode, key, p, node);
                }
                else if (splitpos == 0)
                {
                    int tmp = key;
                    key = p.key[0];
                    node.key[0] = tmp;
                    node.succeedingnode[0] = p.succeedingnode[0];
                    node.succeedingnode[1] = succeedingnode;
                    node.nsize = 1;
                    node.isleaf = p.isleaf;
                    node.nodetype = p.nodetype;
                    node.parentnode = p.parentnode;
                    int i;
                    for (i = 0; i < c - 1; i++)
                    {
                        p.key[i] = p.key[i + 1];
                        p.succeedingnode[i] = p.succeedingnode[i + 1];
                    }
                    p.succeedingnode[c - 1] = p.succeedingnode[c];
                    p.nsize = c - 1;

                    if (p.nodetype == 0)
                    {
                        BTreeNode newroot = new BTreeNode();
                        newroot.key[0] = key;
                        newroot.nsize = 1;
                        newroot.nodetype = 0;
                        newroot.isleaf = false;
                        newroot.succeedingnode[0] = node;
                        newroot.succeedingnode[1] = p;
                        p.nodetype = node.nodetype = 1;
                        p.parentnode = node.parentnode = newroot;
                        state = true;
                    }
                    else
                        state = Insert_BTree2(p.parentnode, key, node, p);
                }
                else if (splitpos == c)
                {
                    int tmp = key;
                    key = p.key[c - 1];
                    node.key[0] = tmp;
                    node.succeedingnode[0] = p.succeedingnode[c];
                    node.succeedingnode[1] = succeedingnode;
                    node.nsize = 1;
                    node.isleaf = p.isleaf;
                    node.nodetype = p.nodetype;
                    node.parentnode = p.parentnode;
                    int i;
                    p.key[c - 1] = 0;
                    p.succeedingnode[c] = null ;
                    p.nsize = c - 1;

                    if (p.nodetype == 0)
                    {
                        BTreeNode newroot = new BTreeNode();
                        newroot.key[0] = key;
                        newroot.nsize = 1;
                        newroot.nodetype = 0;
                        newroot.isleaf = false;
                        newroot.succeedingnode[0] = p;
                        newroot.succeedingnode[1] = node;
                        p.nodetype = node.nodetype = 1;
                        p.parentnode = node.parentnode = newroot;
                        state = true;
                    }
                    else
                        state = Insert_BTree2(p.parentnode, key, p, node);
                }
            }
            return state;
        }

        #endregion

        #region 删除

        public bool Delete_Node(BTreeNode node, int key)
        {
            bool state = false;

            BTreeNode p = node;

            if (p.isleaf)//node为叶子节点
            {
                int c = p.nsize;
                int spos, epos, i;
                spos = epos = -1;
                for (i = 0; i < c; i++)
                {
                    if (p.key[i] == key && spos == -1)
                    {
                        spos = i;
                    }
                    else if (p.key[i] > key && epos == -1)
                    {
                        epos = i;
                        break;
                    }
                }
                if (spos == -1)//没找到key
                {
                    state = false;
                    return state;
                }
                else if (epos == -1)//从spos到最后都是key
                {
                    for (i = spos; i < c; i++)
                    {
                        p.key[i] = 0;
                        p.succeedingnode[i] = null ;
                    }
                    p.nsize = spos;
                }
                else//从spos到epos是key
                {
                    for (i = epos; i < c; i++)
                    {
                        p.key[spos + i] = p.key[epos + i];
                        p.succeedingnode[spos + i] = p.succeedingnode[epos + i];
                    }
                    p.nsize -= epos - spos;
                }
                state = checkJoin(p);//检查是否要合并
            }
            else//node为非叶子节点
            {
                int c = p.nsize;
                int i;
                //bool flag = false;
                //找到第一个大于等于key的键，然后顺着向下找
                for (i = 0; i < c; i++)
                {
                    if (p.key[i] == key)
                    {
                        Delete_Node(p.succeedingnode[i + 1], key);
                        break;
                    }
                    else if (p.key[i] > key)
                    {
                        Delete_Node(p.succeedingnode[i], key);
                        break;
                    }
                }
                if (i == c)
                {
                    state = false;
                    return state;
                }
                state = true;
            }

            return state;
        }
        #endregion

        #region 辅助功能

        //检查是否要合并
        public bool checkJoin(BTreeNode node)
        {
            bool state = false;
            BTreeNode p = node;
            BTreeNode left = findBrother(p, 1);//寻找左兄弟
            BTreeNode right = findBrother(p, 2);//寻找右兄弟
            if (p.nsize >= MINNUM_LEAF)
                return false;
            else if (p.nsize < MINNUM_LEAF && left.nsize > MINNUM_LEAF)
            //p节点的键数小于最小节点数，且左兄弟键数大于最小节点数，则借其左兄弟最后一个键及节点指针
            {
                int i;
                int c = p.nsize;
                for (i = c - 1; i >= 0; i--)
                {
                    p.key[i + 1] = p.key[i];
                    p.succeedingnode[i + 2] = p.succeedingnode[i + 1];
                }
                p.succeedingnode[1] = p.succeedingnode[0];
                p.key[0] = left.key[left.nsize - 1];
                p.succeedingnode[0] = left.succeedingnode[left.nsize];
                left.key[left.nsize - 1] = 0;
                left.succeedingnode[left.nsize] = null;
                left.nsize--;
                p.nsize++;

                int pos = findPos(p);

                if (pos == -1)
                    return false;

                BTreeNode fatherNode = p.parentnode;
                //如果是叶子节点，则将父节点对应键换为该节点的最小键
                if (p.isleaf)
                {
                    fatherNode.key[pos] = p.key[0];
                }

                //如果非叶节点，则将父节点对应键与该节点的最小键对换
                else
                {
                    int tmp = fatherNode.key[pos];
                    fatherNode.key[pos] = p.key[0];
                    p.key[0] = tmp;
                }

            }
            else if (p.nsize < MINNUM_LEAF && right.nsize > MINNUM_LEAF)
            //p节点的键数小于最小节点数，且右兄弟键数大于最小节点数，则借其右兄弟第一个键及节点指针
            {
                int i;
                int c = p.nsize;
                p.key[c] = right.key[0];
                p.succeedingnode[c + 1] = left.succeedingnode[0];
                for (i = 0; i < left.nsize; i++)
                {
                    left.key[i] = left.key[i + 1];
                    left.succeedingnode[i] = left.succeedingnode[i + 1];
                }
                left.key[left.nsize - 1] = 0;
                left.succeedingnode[left.nsize] = null;
                left.nsize--;
                p.nsize++;
                int pos = findPos(right);
                if (pos == -1)
                    return false;
                BTreeNode fatherNode = p.parentnode;
                //如果是叶子节点，则将父节点中右兄弟对应键换为其右兄弟的最小键
                if (p.isleaf)
                {
                    fatherNode.key[pos] = right.key[0];
                }

                //如果非叶节点，则将父节点中右兄弟对应键与其右兄弟的最小键对换
                else
                {
                    int tmp = fatherNode.key[pos];
                    fatherNode.key[pos] = right.key[0];
                    right.key[0] = tmp;
                }

            }
            else if (p.nsize < MINNUM_LEAF && left.nsize < MINNUM_LEAF)
            //本节点及左兄弟都小于最小节点数，则与左兄弟合并
            {
                int i;
                if (p.isleaf)
                {
                    int c = p.nsize;
                    for (i = 0; i < c; i++)
                    {
                        left.key[left.nsize + i] = p.key[i];
                        left.succeedingnode[left.nsize + i] = p.succeedingnode[i];
                    }
                    left.nsize += p.nsize;
                    int pos = findPos(left);
                    state = deleteParentNode(p.parentnode, pos);
                    state &= deleteNode(p);
                    state &= checkJoin(left.parentnode);
                }
                else
                {
                    int c = p.nsize;
                    left.key[left.nsize] = p.succeedingnode[0].key[0];
                    for (i = 0; i < c; i++)
                    {
                        left.key[left.nsize + i + 1] = p.key[i];
                        left.succeedingnode[left.nsize + i + 1] = p.succeedingnode[i];
                    }
                    left.succeedingnode[left.nsize + c + 1] = p.succeedingnode[c];
                    left.nsize += (c + 1);
                    state &= deleteNode(p);
                    state &= checkJoin(left.parentnode);
                }
            }
            else if (p.nsize < MINNUM_LEAF && right.nsize < MINNUM_LEAF)
            //本节点及右兄弟都小于最小节点数，则与右兄弟合并
            {
                int i;
                if (p.isleaf)
                {
                    int c = right.nsize;
                    for (i = 0; i < c; i++)
                    {
                        p.key[left.nsize + i] = right.key[i];
                        p.succeedingnode[left.nsize + i] = right.succeedingnode[i];
                    }
                    p.nsize += right.nsize;
                    int pos = findPos(p);
                    state = deleteParentNode(p.parentnode, pos);
                    state &= deleteNode(right);
                    state &= checkJoin(p.parentnode);
                }
                else
                {
                    int c = right.nsize;
                    p.key[p.nsize] = right.succeedingnode[0].key[0];
                    for (i = 0; i < c; i++)
                    {
                        p.key[left.nsize + i + 1] = right.key[i];
                        p.succeedingnode[p.nsize + i + 1] = right.succeedingnode[i];
                    }
                    p.succeedingnode[p.nsize + c + 1] = right.succeedingnode[c];
                    p.nsize += (c + 1);
                    state &= deleteNode(right);
                    state &= checkJoin(p.parentnode);
                }
            }
            return state;
        }

        //查找兄弟
        public BTreeNode findBrother(BTreeNode p, int type)
        {
            BTreeNode q;
            int pos = findPos(p);
            if (pos + 1 < p.parentnode.nsize)
                return p.parentnode.succeedingnode[pos + 2];
            else
                return null;
        }

        //修改父节点
        public bool deleteParentNode(BTreeNode father, int pos)
        {
            bool state = true;

            for (int i = pos; i < father.nsize - 1; i++)
            {
                father.key[i] = father.key[i + 1];
                father.succeedingnode[i + 1] = father.succeedingnode[i + 2];
            }
            father.nsize--;
            return state;
        }

        //删除节点
        public bool deleteNode(BTreeNode p)
       {
	     if(p != null)
	    {
          p.succeedingnode=null;
		  p.parentnode=null;
		  p = null ;
		  return true;
	    }
	    else
		 return false;
      }

        //查找分裂点
        public int findPos(BTreeNode node)
        {
            BTreeNode p, father;
            p = node;
            father = p.parentnode;
            for (int i = father.nsize - 1; i >= 0; i--)
            {
                if (father.key[i] <= p.key[0])
                    return i;
            }
            return -1;


        }
        #endregion

    }
}