﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;

namespace b_plus
{
    public partial class Form1 : Form
    {
        public process creat=new process ();
        public data data = new data();
        public int[] a = new int[53000000];
        public int[] y = new int[1000];
        data.BTreeNode root;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Stopwatch sw1 = new Stopwatch();
            sw1.Start();
            for (int i = 0; i < 1000; i++)
            {
                creat.InsertBTree(root, y[i]);
            }
            sw1.Stop();
            MessageBox.Show("插入成功\n" + "插入时间：" + sw1.ElapsedMilliseconds.ToString() + "毫秒");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Stopwatch sw1 = new Stopwatch();
            sw1.Start();
            int j = 0;
            string temp = "";
            string text = textBox1.Text;
            for (int i = 0; i < textBox1.TextLength; i++)
            {
                if (text[i] == ',')
                {
                    y[j++] = Convert.ToInt32(temp);
                    temp = "";
                }
                else
                    temp += text[i];

            }
             for (int i = 0; i < j; i++)
            {
                if (creat.Delete_Node(root, y[i]) == null)
                {
                    j--;
                }
            }
            sw1.Stop();
            if (j == 0)
                MessageBox.Show("删除成功\n" + "删除时间：" + sw1.ElapsedMilliseconds.ToString() + "毫秒");
            else
                MessageBox.Show("删除失败\n" + "删除时间：" + sw1.ElapsedMilliseconds.ToString() + "毫秒\n" + "还有" + j + "个未找到");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string temp="";
            Stopwatch sw1 = new Stopwatch();
            Stopwatch sw2 = new Stopwatch();

            sw1.Start();
            string text = textBox1.Text;
            int j = 0;
            int j2 = 0;
            for (int i = 0; i < textBox1.TextLength; i++)
            {
                if (text[i] == ',')
                {
                    y[j++] = Convert.ToInt32(temp);
                    temp = ""; 
                }
                else
                temp += text[i];
                
            }
            j2 = j;
            for (int i = 0; i < j; i++)
            {
                if (creat.selectKey(root, y[i]) == null)
                {
                    j--;
                }
            }
            sw1.Stop();

            sw2.Start();
            for (int i = 0,x=0; i < 53000; i++)//53000000
            {
                if (y[x] == a[i])
                {
                    x++;
                    j2--; 
                }
            }
            sw2.Stop();

            if (j == 0)
              MessageBox.Show("查找成功\n" + "查找时间：" + sw1.ElapsedMilliseconds.ToString() + "毫秒\n" + "普通时间为" + sw2.ElapsedMilliseconds.ToString()); 
            else
              MessageBox.Show("查找失败\n" + "查找时间：" + sw1.ElapsedMilliseconds.ToString() + "毫秒\n"+"还有"+j+"个未找到"+"普通时间为" + sw2.ElapsedMilliseconds.ToString());

        } 
        
        public void button4_Click(object sender, EventArgs e)
        {
            Stopwatch sw1 = new Stopwatch();
            sw1.Start();
            root=creat.Create_BTree(1000);
            Random reum = new Random();
            for (int i = 0; i < 53000; i++)//53000000
            {
                a[i] = reum.Next(530000000);
                creat.InsertBTree(root, a[i]);
            }
            sw1.Stop();
            MessageBox.Show("生成成功\n"+"生成时间："+sw1.ElapsedMilliseconds.ToString()+"毫秒");

        }
        
        public void button5_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 1000; i++)
            {
                Random reum = new Random();
                y[i] = reum.Next(530000000);
            }
            for (int i = 0; i < 1000; i++)
            {
                textBox1.AppendText(y[i].ToString());
                textBox1.AppendText( ",");
            }
            y = new int[1000];

        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            y = new int[1000];   
        }
    }
}
