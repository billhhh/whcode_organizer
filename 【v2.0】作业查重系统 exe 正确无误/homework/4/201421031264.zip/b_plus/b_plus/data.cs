﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace b_plus
{
    public  class data
    {
        #region 定义常数

        public const int M = 10000;                   // B+树的阶
        public const int L = 1000;                    //B+树
        public const int MINNUM_KEY =((M + 1) / 2) - 1 ;        // 内部节点最小键值个数
        public const int MAXNUM_KEY = M - 1;      // 内部节点最大键值个数
        public const int MINNUM_CHILD = (M + 1) / 2; // 最小子树个数
        public const int MAXNUM_CHILD = M; // 最大子树个数
        public const int MINNUM_LEAF = (L + 1) / 2;   // 最小叶子结点键值个数
        public const int MAXNUM_LEAF =L ;    // 最大叶子结点键值个数

        #endregion

        #region 树的结构

        public class BTreeNode
        {
            public int[] key = new int[M-1];//关键字数组
            public int nodetype;//节点类型：0-根，1-内部节点，2-外节点
            public bool isleaf;//是否为叶节点
            public int nsize;//关键字个数
            public BTreeNode[] succeedingnode = new BTreeNode[M];
            public BTreeNode parentnode;
        }

        #endregion

    }
}
