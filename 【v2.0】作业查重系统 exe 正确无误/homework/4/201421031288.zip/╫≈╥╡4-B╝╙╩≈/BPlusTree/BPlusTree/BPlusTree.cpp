// BPlusTree.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#define du 3  //���3
#define min_du (int)ceil(du/2.0) //����ȡ�� 2
#define up (int)ceil((du+1)/2.0)  //2
#define down (int)floor((du+1)/2.0)  //����ȡ��2

typedef struct BPnode_base     //
{
	int key;
	struct BPlusNode *BPnext;
}BPbNode;

typedef struct BPlusNode      //
{
	char nodetype; //�ڵ����� 0 1 2
	int keysize;   //�ؼ��ָ���
	BPbNode keyall[du];//���� 
	struct BPlusNode *parent;
	struct LeafNode *LFnext;  //ָ��Ҷ�ӽڵ�
	BPlusNode()
	{
		keysize=0;
		parent=NULL;
		LFnext=NULL;
	}
}BPNode;

typedef struct LFnode_base		//
{
	int key;//�ؼ���
	int address; //�ļ���ַ
}LFbNode;

 typedef struct LeafNode			//
{
	int keysize;   //�ؼ��ָ���
	LFbNode keyall[du];//����
	struct LeafNode *LFnext;//
	LeafNode()//���캯��
	{
		keysize=0;
		LFnext=NULL;
	}
}LFNode;

BPNode *root=NULL; //��ָ��
LFNode *leaf=NULL;

bool find(BPNode *node,int key)
{
	int i,j;
	BPNode *nd;
	nd = node;
	if(nd) //�ǿ�
	{
		for(i=0;i < nd->keysize;i++)   //���жϽڵ��ڲ��Ƿ���
		{
			if(key == nd->keyall[i].key) 
			return true;
		}
		if(key > nd->keyall[nd->keysize-1].key)
		{
			return false;
		}

		if(nd->keysize == 1)
		{
			if(key == nd->keyall[0].key) 
				return true;
			else 
				return false;
		}
		else
		{
			for(i=0;i < nd->keysize-1;i++)  //������ڵ�ݹ�
			{
				j=i+1;
				if(key < nd->keyall[i].key)
				{
					nd = nd->keyall[i].BPnext;
					return find(nd,key);  //��Ȼ���˼�return ��TvT��
				}
				else if(key < nd->keyall[j].key)
				{
					nd = nd->keyall[j].BPnext;
					return find(nd,key);
				}
			
			}
		
		}

	}

	return false;

}


int getsortpos(BPNode *node,int key)
{
	int i,j;
	if(node->keysize == 1)
	{
		if(key < node->keyall[0].key) return 0;
		else return 1;
	}
	else
	{
		for(i=0;i < node->keysize-1;i++)
		{
			j=i+1;
			if(key < node->keyall[i].key)
				return i;
			else if(key < node->keyall[j].key)
				return j;
		}
		return node->keysize;  //�������

	}
}

BPNode *findleaf(BPNode *node,int key) //���keyС��node�е����ֵ
{
	int pos;
	BPNode *next;
	next = node;
	while(next)     //�ҵ�key��Ҫ�����Ҷ�ӽڵ�
	{
		if(next->LFnext)
		{
			return next;
		}
		pos=getsortpos(next,key);
		next=next->keyall[pos].BPnext;
	}
	return NULL;
}


void sort_to_LFnode(BPNode *node,int key)   //���뵽Ҷ��
{
	int i,pos;
	LFNode *lnd;
	//BPNode *pa;
	pos=getsortpos(node,key); 
	lnd = node->LFnext; //�ҳ�Ҷ�ӣ�����Ӧ�ı�
	if(pos == node->keysize)      //���
	{
		node->keyall[node->keysize].key = key;    //��¼
		node->keyall[node->keysize].BPnext = NULL;
		node->keysize++;    //����
		lnd->keyall[lnd->keysize].key = key;
		lnd->keyall[lnd->keysize].address = 1288;
		lnd->keysize++;

	}
	else
	{
		for(i = node->keysize;i > pos;i--)   //����ǰ���ƶ�
		{
			node->keyall[i].key = node->keyall[i-1].key;
			node->keyall[i].BPnext = node->keyall[i-1].BPnext;
			lnd->keyall[i].key = lnd->keyall[i-1].key;
			lnd->keyall[i].address = lnd->keyall[i-1].address;
		}
		//�½ڵ����
		node->keyall[pos].key = key;
		node->keyall[pos].BPnext = NULL;
		node->keysize++;
		lnd->keyall[pos].key = key;
		lnd->keyall[pos].address=1288;
		lnd->keysize++;
	}


}

void sort_to_BPnode(BPNode *node,int key,BPNode *node1,BPNode *node2)   //���뵽��Ҷ��
{
	int i,pos;
	pos=getsortpos(node,key);   //key��node1�����ֵ
	for(i = node->keysize;i > pos;i--)   //����ǰ���ƶ�  key����
	{
		node->keyall[i].key = node->keyall[i-1].key;
		node->keyall[i].BPnext = node->keyall[i-1].BPnext;
	}
	//�½ڵ����
	node->keyall[pos].key = key;
	node->keyall[pos].BPnext = node1;    //��סnode1
	node->keyall[pos+1].BPnext = node2;  //��סnode2
	node->keysize++;

}
LFNode *findlfpa(LFNode *lnd)
{
	LFNode *pa;
	pa=leaf;
	while(pa)
	{
		if(pa->LFnext == lnd) return pa;
		pa = pa->LFnext;
	}
	return NULL;
}

void splitBPNode(BPNode *node,int key)  //��Ҷ�ӷ���
{


}

void splitLFNode(BPNode *node,int key)  //Ҷ�ӷ���
{
	BPNode *nd,*pa;
	BPNode *node1,*node2;
	LFNode *lfnode1,*lfnode2,*lnd,*lfpa;
	int pos,i;
	nd=node;
	pa=nd->parent;    //��ס���ڵ�
	lnd=node->LFnext;
	pos=getsortpos(nd,key);
	if(nd == root) //ֻ��root��ʱ��
	{
		root=new BPNode;    //
		node1=new BPNode;   //
		node2=new BPNode;   //
		lfnode1=new LFNode; //
		lfnode2=new LFNode; //
		if(pos == 0)
		{
			node1->keyall[0].key = key;
			node1->keyall[0].BPnext = NULL;
			lfnode1->keyall[0].key = key;
			lfnode1->keyall[0].address = 1288;
			for(i=1;i<up;i++)
			{
				node1->keyall[i].key = nd->keyall[i-1].key;
				node1->keyall[i].BPnext = nd->keyall[i-1].BPnext;
				lfnode1->keyall[i].key = lnd->keyall[i-1].key;
				lfnode1->keyall[i].address = lnd->keyall[i-1].address;
			}
			for(i=0;i<down;i++)
			{
				node2->keyall[i].key = nd->keyall[i+up-1].key;
				node2->keyall[i].BPnext = nd->keyall[i+up-1].BPnext;
				lfnode2->keyall[i].key = lnd->keyall[i+up-1].key;
				lfnode2->keyall[i].address = lnd->keyall[i+up-1].address;
			}

		}
		else if(pos == du)   //3
		{
			for(i=0;i<up;i++)
			{
				node1->keyall[i].key = nd->keyall[i].key;
				node1->keyall[i].BPnext = nd->keyall[i].BPnext;
				lfnode1->keyall[i].key = lnd->keyall[i].key;
				lfnode1->keyall[i].address = lnd->keyall[i].address;
			}
			for(i=0;i<down-1;i++)
			{
				node2->keyall[i].key = nd->keyall[i+up].key;
				node2->keyall[i].BPnext = nd->keyall[i+up].BPnext;
				lfnode2->keyall[i].key = lnd->keyall[i+up].key;
				lfnode2->keyall[i].address = lnd->keyall[i+up].address;
			}
			node2->keyall[down-1].key = key;
			node2->keyall[down-1].BPnext = NULL;
			lfnode2->keyall[down-1].key = key;
			lfnode2->keyall[down-1].address = 1288;

		}
		else if(pos == 1)  //1
		{
			node1->keyall[0].key = nd->keyall[0].key;
			node1->keyall[0].BPnext = nd->keyall[0].BPnext;
			lfnode1->keyall[0].key = lnd->keyall[0].key;
			lfnode1->keyall[0].address = lnd->keyall[0].address;

			node1->keyall[1].key = key;
			node1->keyall[1].BPnext = NULL;
			lfnode1->keyall[1].key = key;
			lfnode1->keyall[1].address = 1288;	
			for(i=0;i < down;i++)
			{	
				node2->keyall[i].key = nd->keyall[i+1].key;
				node2->keyall[i].BPnext = nd->keyall[i+1].BPnext;
				lfnode2->keyall[i].key = lnd->keyall[i+1].key;
				lfnode2->keyall[i].address = lnd->keyall[i+1].address;
			}

		}
		else       // pos == 2  
		{
			for(i=0;i < up;i++)
			{
				node1->keyall[i].key = nd->keyall[i].key;
				node1->keyall[i].BPnext = nd->keyall[i].BPnext;
				lfnode1->keyall[i].key = lnd->keyall[i].key;
				lfnode1->keyall[i].address = lnd->keyall[i].address;
			}
			node2->keyall[0].key = key;
			node2->keyall[0].BPnext = NULL;
			lfnode2->keyall[0].key = key;
			lfnode2->keyall[0].address = 1288;

			node2->keyall[1].key = nd->keyall[2].key;
			node2->keyall[1].BPnext = nd->keyall[2].BPnext;
			lfnode2->keyall[1].key = lnd->keyall[2].key;
			lfnode2->keyall[1].address = lnd->keyall[2].address;

		}
		node1->parent=root;   //���ڵ�
		node1->keysize=up;
		node1->nodetype=1;    //Ҷ��
		node1->LFnext=lfnode1;
		node2->parent=root;
		node2->keysize=down;
		node2->nodetype=1;
		node2->LFnext=lfnode2;
		lfnode1->keysize=up;
		lfnode2->keysize=down;
		lfnode1->LFnext=lfnode2;//Ҷ����������
		lfnode2->LFnext=NULL;
		leaf=lfnode1;
		root->keyall[0].key = node1->keyall[up-1].key;
		root->keyall[0].BPnext = node1;
		root->keyall[1].key = node2->keyall[down-1].key;
		root->keyall[1].BPnext = node2;
		root->keysize=2;
		root->LFnext=NULL;
		root->parent=NULL;
		root->nodetype=0;
		delete nd;  //�ͷŵ�ԭroot
		delete lnd; //�ͷŵ�ԭҶ�ӽڵ�

	}
	else //nd ����root
	{
		node1=new BPNode;   //
		node2=new BPNode;   //
		lfnode1=new LFNode; //
		lfnode2=new LFNode; //
		if(pos == 0)
		{
			node1->keyall[0].key = key;
			node1->keyall[0].BPnext = NULL;
			lfnode1->keyall[0].key = key;
			lfnode1->keyall[0].address = 1288;
			for(i=1;i<up;i++)
			{
				node1->keyall[i].key = nd->keyall[i-1].key;
				node1->keyall[i].BPnext = nd->keyall[i-1].BPnext;
				lfnode1->keyall[i].key = lnd->keyall[i-1].key;
				lfnode1->keyall[i].address = lnd->keyall[i-1].address;
			}
			for(i=0;i<down;i++)
			{
				node2->keyall[i].key = nd->keyall[i+up-1].key;
				node2->keyall[i].BPnext = nd->keyall[i+up-1].BPnext;
				lfnode2->keyall[i].key = lnd->keyall[i+up-1].key;
				lfnode2->keyall[i].address = lnd->keyall[i+up-1].address;
			}

		}
		else if(pos == du)   //3
		{
			for(i=0;i<up;i++)
			{
				node1->keyall[i].key = nd->keyall[i].key;
				node1->keyall[i].BPnext = nd->keyall[i].BPnext;
				lfnode1->keyall[i].key = lnd->keyall[i].key;
				lfnode1->keyall[i].address = lnd->keyall[i].address;
			}
			for(i=0;i<down-1;i++)
			{
				node2->keyall[i].key = nd->keyall[i+up].key;
				node2->keyall[i].BPnext = nd->keyall[i+up].BPnext;
				lfnode2->keyall[i].key = lnd->keyall[i+up].key;
				lfnode2->keyall[i].address = lnd->keyall[i+up].address;
			}
			node2->keyall[down-1].key = key;
			node2->keyall[down-1].BPnext = NULL;
			lfnode2->keyall[down-1].key = key;
			lfnode2->keyall[down-1].address = 1288;

		}
		else if(pos == 1)  //1
		{
			node1->keyall[0].key = nd->keyall[0].key;
			node1->keyall[0].BPnext = nd->keyall[0].BPnext;
			lfnode1->keyall[0].key = lnd->keyall[0].key;
			lfnode1->keyall[0].address = lnd->keyall[0].address;

			node1->keyall[1].key = key;
			node1->keyall[1].BPnext = NULL;
			lfnode1->keyall[1].key = key;
			lfnode1->keyall[1].address = 1288;	
			for(i=0;i < down;i++)
			{	
				node2->keyall[i].key = nd->keyall[i+1].key;
				node2->keyall[i].BPnext = nd->keyall[i+1].BPnext;
				lfnode2->keyall[i].key = lnd->keyall[i+1].key;
				lfnode2->keyall[i].address = lnd->keyall[i+1].address;
			}

		}
		else       // pos == 2  
		{
			for(i=0;i < up;i++)
			{
				node1->keyall[i].key = nd->keyall[i].key;
				node1->keyall[i].BPnext = nd->keyall[i].BPnext;
				lfnode1->keyall[i].key = lnd->keyall[i].key;
				lfnode1->keyall[i].address = lnd->keyall[i].address;
			}
			node2->keyall[0].key = key;
			node2->keyall[0].BPnext = NULL;
			lfnode2->keyall[0].key = key;
			lfnode2->keyall[0].address = 1288;

			node2->keyall[1].key = nd->keyall[2].key;
			node2->keyall[1].BPnext = nd->keyall[2].BPnext;
			lfnode2->keyall[1].key = lnd->keyall[2].key;
			lfnode2->keyall[1].address = lnd->keyall[2].address;

		}
		if(pa->keysize < du) //���ڵ�ɲ���
		{
			sort_to_BPnode(pa,node1->keyall[up-1].key,node1,node2);
			node1->parent=pa;   //���ڵ�
			node1->keysize=up;
			node1->nodetype=1;    //Ҷ��
			node1->LFnext = lfnode1;
			node2->parent=pa;
			node2->keysize=down;
			node2->nodetype=1;
			node2->LFnext = lfnode2;
			lfnode1->keysize = up;
			lfnode2->keysize = down;
			lfnode1->LFnext = lfnode2;//Ҷ����������
			lfnode2->LFnext = lnd->LFnext; //ָ��ԭ����
			if(lnd == leaf) //Ҷ��ͷָ��
			{
				leaf = lfnode1;
			}
			else
			{
				lfpa = findlfpa(lnd);
				lfpa->LFnext = lfnode1;
			}
			delete nd;
			delete lnd;

		}
		else  //���ڵ㲻�ɲ��룬������������
		{
			//����
		}


	}

}

void insert_to_node(BPNode *node,int key)
{
	BPNode *nd,*next,*BPleaf;
	nd=node;
	if(key > root->keyall[root->keysize - 1].key)  //�����ֵ���
	{
		next = root; //��root������
		while(next)  //��������θ���
		{
			if(next->LFnext) //�����Ҷ��
			{
				sort_to_LFnode(next,key);
				break;
			}
			next->keyall[next->keysize - 1].key = key;
			next = next->keyall[next->keysize - 1].BPnext; //��root������

		}

	}
	else
	{
		BPleaf=findleaf(nd,key);
		if(BPleaf->keysize < du)   //Ҷ�ӿɲ���
		{
			sort_to_LFnode(BPleaf,key);
		}
		else  //Ҷ�ӷ���
		{
			splitLFNode(BPleaf,key);
		}

	}

}

void insert_key(int key)
{
	BPNode *node;
	LFNode *lfnode;
	if(!root) //��Ϊ��
	{
		node=new BPNode;
		lfnode=new LFNode;
		node->keyall[node->keysize].key=key;
		node->keyall[node->keysize].BPnext=NULL;
		node->parent=NULL;   //���ڵ�
		node->LFnext=lfnode; //Ҷ�ڵ�
		node->nodetype=1;    //Ҷ��
		node->keysize++;     //
		lfnode->keyall[lfnode->keysize].key=key;
		lfnode->keyall[lfnode->keysize].address=1288;
		lfnode->LFnext=NULL;
		lfnode->keysize++;  //
		
		root=node;
		leaf=lfnode;
	}
	else
	{
		if(!find(root,key))
		{
			insert_to_node(root,key);
		}
		else
		{
			printf("�Ѵ���");
		}


	}


}



int _tmain(int argc, _TCHAR* argv[])
{
	int i,key;
	LFNode *lfnode;
	//printf("����5�����֣�\n");
	//scanf("%d,%d,%d,%d,%d\n",&table[0],&table[1],&table[2],&table[3],&table[4]);
	while(1)
	{
		printf("����key��\n");
		scanf("%d",&key); //
		if(key == 0) break;
		insert_key(key);
	}
	lfnode = leaf;
	while(lfnode)
	{
		for(i=0;i < lfnode->keysize;i++)
		{
			printf("%d ",lfnode->keyall[i].key);
		}
		lfnode = lfnode->LFnext;
	}
	printf("\n=========");
	getchar();
	getchar();
	return 0;
}

