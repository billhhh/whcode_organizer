#include <iostream>
#include <cstdlib>
#include <cmath>

using namespace std;

#define M 50

typedef struct myData
{
	char data[25];
}myData;

typedef struct myBPTreeNode
{
	bool isleaf;   //�Ƿ�Ҷ�ӽ��
	int keyNum;    //�ؼ�ֵ����Ŀ
	int keys[M];   //�ؼ�ֵ
	myBPTreeNode *child[M+1];   // ���ӽ��
	myBPTreeNode *parent;       //���׽��
	myData *nodeData[M];        // ���ݣ�ֻ��Ҷ�ӽ���������
}myBPTreeNode;

myBPTreeNode *root;
myData *m_data;

void initData()
{
	int i;
	m_data = new myData[20*1024*1024];
	char temp[25];
	char index[10];
	for(i=0;i<20*1024*1024;i++)
	{
		strcpy_s(temp,"Data");
		itoa(i,index,10);
		strcat_s(temp,index);
		strcpy_s(m_data[i].data,temp);
	}
}

void findData(int key)
{
	for(int i=0;i<20*1024*1024;i++)
	{
		if(i == key)
		{
			for(int j=0;j<25;j++)
			{
				cout<<m_data[i].data[j];
			}
			cout<<endl;
			break;
		}
	}
}

void initNode(myBPTreeNode ** node)
{
	*node = (myBPTreeNode*)malloc(sizeof(myBPTreeNode));
	(*node)->isleaf = true;       //��ʼ��ΪҶ�ӽڵ�
	(*node)->keyNum = 0;       //�ؼ��ָ���Ϊ0
	(*node)->parent = NULL;      //��ʼ���ڵ�ĸ��ڵ�Ϊ��
	for (int i = 0; i < M+1; i++)
	{
		((*node)->child)[i] = NULL;
	}
	for (int i = 0; i < M; i++)
	{
		((*node)->nodeData)[i] = NULL;
	}
}

myBPTreeNode *findNode(myBPTreeNode *node, int key)
{
	if(node->isleaf)     //�ж��Ƿ�ΪҶ�ӽ�㣬������ֹͣ���������
	{
		return node;
	}
	else
	{
		myBPTreeNode *temp;

		if(node->keys[0] > key)      //�Ƿ�С�������keyֵ
		{
			temp = findNode(node->child[0],key);
		}
		else if(node->keys[node->keyNum-1] <= key)     //�Ƿ���ڵ������е�keyֵ
		{
			temp = findNode(node->child[node->keyNum],key);
		}
		else                             //����С�����֮��
		{
			for(int i=1;i<node->keyNum;i++)
			{
				if(node->keys[i]>key)
				{
					temp = findNode(node->child[i],key);
					break;
				}
			}
		}
		return temp;
	}
}

bool isSpilt(myBPTreeNode *node)
{
	if(node->keyNum == M)
	{
		return true;
	}
	else
	{
		return false;
	}
}

int insert(myBPTreeNode *node, int key)
{
	bool hasInsert = false;
	int index;
	for(int i=node->keyNum-1;i>=0;i--)
	{
		if(node->keys[i]<key)
		{
			index = i+1;
			node->keys[i+1] = key;
			node->keyNum++;
			hasInsert = true;
			break;
		}
		else
		{
			node->keys[i+1] = node->keys[i];
		}
	}
	if(!hasInsert)
	{
		index = 0;
		node->keys[0] = key;
		node->keyNum++;
	}
	return index;
}

void spiltInternalNode(myBPTreeNode *node)
{
	if(node == root)
	{
		int i = (int)floor(M/2.0);
		int k;
		myBPTreeNode *newRoot;
		myBPTreeNode *rightChild;
		initNode(&newRoot);
		newRoot->keys[0] = node->keys[i];
		newRoot->keyNum++;
		newRoot->isleaf = false;
		initNode(&rightChild);
		rightChild->isleaf = node->isleaf;
		
		if(!node->isleaf)
			k = i+1;
		else
			k = i;
		for(int j=k;j<node->keyNum;j++)
		{
			rightChild->keys[j-k] = node->keys[j];
			rightChild->keyNum++;
		}
		for(int j=i+1;j<=node->keyNum;j++)
		{
			if(node->child[j] != NULL)
			{
				rightChild->child[j-i-1] = node->child[j];
				rightChild->child[j-i-1]->parent = rightChild;
			}
		}

		node->keyNum -= rightChild->keyNum;

		newRoot->child[0] = node;
		newRoot->child[1] = rightChild;

		root = newRoot;
		node->parent = root;
		rightChild->parent = root;

	}
	else
	{
		int i = (int)floor(M/2.0);
		int k;
		myBPTreeNode *parentNode = node->parent;
		myBPTreeNode *rightChild;
		initNode(&rightChild);
		rightChild->isleaf = node->isleaf;

		if(!node->isleaf)
			k = i+1;
		else
			k = i;
		for(int j=k;j<node->keyNum;j++)
		{
			rightChild->keys[j-k] = node->keys[j];
			rightChild->keyNum++;
		}
		for(int j=i+1;j<=node->keyNum;j++)
		{
			if(node->child[j] != NULL)
			{
				rightChild->child[j-i-1] = node->child[j];
				rightChild->child[j-i-1]->parent = rightChild;
			}
		}

		node->keyNum = node->keyNum - rightChild->keyNum;

		int index = insert(parentNode,node->keys[i]);
		for(int j=parentNode->keyNum-1;j>index;j--)
		{
			parentNode->child[j+1] = parentNode->child[j];
		}
		node->parent = parentNode;
		rightChild->parent = parentNode;
		parentNode->child[index] = node;
		parentNode->child[index+1] = rightChild;
		parentNode->isleaf = false;

		if(isSpilt(parentNode))
		{
			spiltInternalNode(parentNode);
		}
	}
}

void findNodeData(int key,int mode)
{
	myBPTreeNode *newNode;
	newNode = findNode(root,key);
	int low = 0;
	int high = newNode->keyNum-1;
	int mid;
	while(low<=high)
	{
		mid = (low + high)/2;
		if(newNode->keys[mid] == key)
			break;
		else if(newNode->keys[mid] > key)
			high = mid - 1;
		else
			low = mid + 1;
	}

	if(mode == 1)
	{
		for(int i=0;i<25;i++)
		{
			cout<<newNode->nodeData[mid]->data[i];
		}
		cout<<endl;
	}
	else if(mode == 2)
	{
		cout<<"�������� "<<key<<" ������:"<<endl;
		char str[25];
		cin>>str;
		strcpy_s(newNode->nodeData[mid]->data,str);
	}
}

void insertNode(int key)
{
	if(root->keyNum == 0)      //�����Ϊ��
	{
		root->keys[0] = key;
		root->keyNum++;
	}
	else                      //����㲻Ϊ��
	{
		myBPTreeNode *newNode;
		newNode = findNode(root,key);    //�ҵ�Ҫ����ĵ�
		insert(newNode,key);             //�����µ�keyֵ
		
		if(isSpilt(newNode))             //�ж��Ƿ�Ҫ����
		{
			spiltInternalNode(newNode); 
		}

		newNode = findNode(root,key);  //�ҵ����Ѻ��²����key���ڵ�Ҷ�ӽ�㣬�ٰ��������Ӧ��key��������
		if(newNode == root)
		{
			newNode = root;
			for(int j=0;j<newNode->keyNum;j++)
			{
				newNode->nodeData[j] = &m_data[newNode->keys[j]];
			}
		}
		else
		{
			for(int i=0;i<newNode->keyNum;i++)
			{
				newNode->nodeData[i] = &m_data[newNode->keys[i]];
			}
		}
	}
}
