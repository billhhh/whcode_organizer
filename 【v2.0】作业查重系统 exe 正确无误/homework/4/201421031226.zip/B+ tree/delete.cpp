#include "bplustree.h"

extern struct node_t * alloc_node();
extern void free_node(struct node_t * node);
extern struct data_block_t * alloc_db();
extern void free_db(struct data_block_t * page);


struct data_block_t * merge_two_db(struct node_t * leaf ,int pos_left ,int pos_right)		//�ϲ��������ݿ�ڵ㣬ʧ�ܷ���0
{
	struct data_block_t * left = (struct data_block_t *) leaf->pointer[pos_left];
	struct data_block_t * right = (struct data_block_t *) leaf->pointer[pos_right];
	
	if((left->size != DBSIZE / 2) || (right->size != DBSIZE / 2))
	{
		printf("Data block not empty enough,Should not happen!\n");
		return 0;
	}
	
	struct data_block_t * new_db = alloc_db();				//�����µĽڵ�
	 new_db->size = left->size + right->size;
	 
	 memcpy(new_db->array ,left->array ,left->size * 4);
	 memcpy(new_db->array + left->size ,right->array ,right->size *4);
	 
	 for(int i = pos_right ;i < leaf->cur_num - 1 ;i++)			//�޸�Ҷ�ӽڵ��е�����
	 {
		leaf->key[i] = leaf->key[i + 1];
		leaf->pointer[i] = leaf->pointer[i + 1];
	 }
	 
	 leaf->cur_num--;
	 
	 leaf->pointer[pos_left] = new_db;
	 leaf->key[pos_left] = new_db->array[new_db->size - 1];
	 
	 free_db(left);
	 free_db(right);
	 
	 return new_db;
}

struct node_t * merge_two_node(struct node_t * parent ,int pos_left ,int pos_right)			//�ϲ������ڵ㣬ʧ�ܷ���0
{
	struct node_t * left = (struct node_t *) parent->pointer[pos_left];
	struct node_t * right = (struct node_t *) parent->pointer[pos_right];
	
	if((left->cur_num != KEYNUM / 2) || (right->cur_num != KEYNUM / 2))
	{
		printf("Internal node not empty enough,Should not happen!\n");
		return 0;
	}
	
	struct node_t * new_node = alloc_node();						//�����½ڵ�����
	new_node->is_leaf = left->is_leaf;
	new_node->cur_num = left->cur_num + right->cur_num;
	new_node->sibling = right->sibling;
	new_node->parent = parent;
	
	memcpy(new_node->key ,left->key ,left->cur_num * 4);
	memcpy(new_node->key + left->cur_num ,right->key ,right->cur_num * 4);
	
	memcpy(new_node->pointer ,left->pointer ,left->cur_num * 4);
	memcpy(new_node->pointer + left->cur_num ,right->pointer ,right->cur_num * 4);
	
	for(int i = pos_right ;i < parent->cur_num - 1 ;i++)			//�޸ĸ��ڵ��е�����
	{
		parent->key[i] = parent->key[i + 1];
		parent->pointer[i] = parent->pointer[i + 1];
	}
	
	parent->cur_num--;
	
	parent->key[pos_left] = new_node->key[new_node->cur_num - 1];
	parent->pointer[pos_left] = new_node;
	
	free_node(left);
	free_node(right);
	
	return new_node;
}

void borrow_node_from_right(int active_in_parent ,struct node_t * active ,struct node_t * passive)		//��passive�н�һ��Ԫ�ظ�active
{
	struct node_t * borrowed_node = (struct node_t *) passive->pointer[0];
	int borrowed_key = passive->key[0];
	struct node_t * parent = active->parent;
	
	for(int i = 0 ;i < passive->cur_num - 1 ;i++)			//�ƶ�����ڵ�Ԫ��
	{
		passive->pointer[i] = passive->pointer[i + 1];
		passive->key[i] = passive->key[i + 1];
	}
	
	passive->cur_num--;
	
	active->pointer[active->cur_num] = borrowed_node;
	active->key[active->cur_num] = borrowed_key;
	active->cur_num++;
	
	parent->key[active_in_parent] = borrowed_key;
}

void borrow_node_from_left(int passive_in_parent ,struct node_t * active,struct node_t * passive)
{
	struct node_t * parent = active->parent;
	struct node_t * borrowed_node = (struct node_t *) passive->pointer[passive->cur_num - 1];
	int key = passive->key[passive->cur_num - 1];
	
	for(int i = active->cur_num - 1 ;i >=0 ;i--)
	{
		active->pointer[i + 1] = active->pointer[i];
		active->key[i + 1] = active->key[i];
	}
	
	active->pointer[0] = borrowed_node;
	active->key[0] = key;
	active->cur_num++;
	
	passive->cur_num--;
	
	parent->key[passive_in_parent] = passive->key[passive->cur_num - 1];
}

void borrow_data_from_left(struct node_t * leaf ,int passive_in_leaf ,struct data_block_t * active ,struct data_block_t * passive)
{
	int element = passive->array[passive->size - 1];
	
	for(int i = active->size - 1 ;i >= 0 ;i--)
		active->array[i + 1] = active->array[i];
		
	active->array[0] = element;
	active->size++;
	
	passive->size--;
	
	leaf->key[passive_in_leaf] = passive->array[passive->size - 1];
}

void borrow_data_from_right(struct node_t * leaf ,int active_in_leaf ,struct data_block_t * active ,struct data_block_t * passive)
{
	int element = passive->array[0];
	
	for(int i = 0;i < passive->size - 1 ;i++)
		passive->array[i] = passive->array[i + 1];
		
	active->array[active->size] = element;
	active->size++;
	
	passive->size--;
	
	leaf->key[active_in_leaf] = element;
}

void delete_data_from_db(struct data_block_t * cur_db ,int pos)
{
	for(int i = pos ;i < cur_db->size - 1 ;i++)
		cur_db->array[i] = cur_db->array[i + 1];
		
	cur_db->size--;
}

int delete_key(struct node_t * root ,int key)
{
	struct node_t * cur_node = root;
	struct node_t * parent_node, * sibling_node;
	
	while(!(cur_node->is_leaf))				//�����ڽڵ㣬�����ڵ�Ԫ�ز���KEYNUM/2������ֵܽڵ��һ��Ԫ�أ�����ֵܽڵ�Ҳ����KEYNUM/2����ϲ������ڵ�
	{
		int cnt = 0;
		
		if(cur_node->cur_num < KEYNUM / 2)		//���ڽڵ�Ԫ�ز���KEYNUM/2�ģ����Դ��ֵܽڵ��һ��Ԫ�أ�����ֵܽڵ�Ҳ���㣬��ϲ������ڵ�
		{
			parent_node = cur_node->parent;
			
			if(parent_node == 0 || parent_node->cur_num == 1)				//������ڵ�Ϊ0�򸸽ڵ�Ԫ�ظ���Ϊ1��ֱ��pass
				goto PASS_NODE;
			
			while(cur_node != parent_node->pointer[cnt])
				cnt++;
				
			if(cnt == parent_node->cur_num - 1)		//���cur_node�Ǹ��ڵ�����Ԫ�أ���ѡ����ߵ��ֵ�
			{
				sibling_node = (struct node_t *) parent_node->pointer[cnt - 1];
				
				if(sibling_node->cur_num < KEYNUM / 2)		//�ֵܽڵ㲻�㣬�ϲ������ڵ�
					cur_node = merge_two_node(parent_node ,cnt - 1,cnt);
				else									//���򣬴����ֵܽ�һ��
					borrow_node_from_left(cnt - 1 ,cur_node ,sibling_node);
			}
			else			//����ѡ���ұߵ��ֵ�
			{
				sibling_node = (struct node_t *) parent_node->pointer[cnt + 1];
				
				if(sibling_node->cur_num < KEYNUM / 2)		//�ֵܽڵ㲻�㣬�ϲ����ڵ�
					cur_node = merge_two_node(parent_node ,cnt ,cnt + 1);
				else									//���򣬴����ֵܽ�һ��
					borrow_node_from_right(cnt ,cur_node ,sibling_node);
			}
		}
		
PASS_NODE:		
		int i = 0;
		
		while((key > cur_node->key[i]) && (i < cur_node->cur_num))
			i++;
		
		if(i == cur_node->cur_num)			//ɾ��һ�����κ������������������
		{
			printf("Can not find key:%d in node,make sure key exists!\n",key);
			return 0;
		}
		
		cur_node = (struct node_t *) cur_node->pointer[i];
	}
	//���е���һ����cur_node�Ѿ���Ҷ�ӽڵ���
	int j = 0;
	
	while((key > cur_node->key[j]) && (j < cur_node->cur_num))
		j++;
	
	if(j == cur_node->cur_num)
	{
		printf("Can not find key:%d in leaf,make sure key exists!\n",key);
		return 0;
	}
	
	struct data_block_t * cur_db = (struct data_block_t *) cur_node->pointer[j];
	struct data_block_t * sibling_db;
	
	int pos_in_db = binary_search(cur_db->array ,cur_db->size ,key);
	
	if(cur_db->array[pos_in_db] != key)			//data block���Ҳ�����˵��key������
	{
		printf("Can not find key %d in data block,make sure key exists!\n",key);
		return 0;
	}
	
	delete_data_from_db(cur_db ,pos_in_db);
	
	if(cur_node->parent == 0 || cur_node->cur_num == 1)
		goto PASS_LEAF;
	
	int new_index;
	struct node_t * upper_layer , * cur_layer , * down_layer;
	int cur_index ,upper_index;
	
	if(pos_in_db == cur_db->size)				//ɾ����������data block�����ģ���Ҫ�����ϲ�������ֵ
	{
		new_index = cur_db->array[pos_in_db - 1];
		
		cur_node->key[j] = new_index;
		
		upper_layer = cur_node->parent;
		cur_layer = cur_node;
		down_layer = (struct node_t *) cur_db;
		
		while(upper_layer)
		{
			cur_index = 0;
			
			while(cur_layer->pointer[cur_index] != (void *) down_layer)			
				cur_index++;
			
			if(cur_index == cur_layer->cur_num - 1)				//����ǽڵ����ұ�Ԫ�أ�������ϲ�����
			{
				upper_index = 0;
				
				while(upper_layer->pointer[upper_index] != cur_layer)
					upper_index++;
					
				upper_layer->key[upper_index] = new_index;
				
				down_layer = cur_layer;
				cur_layer = upper_layer;
				upper_layer = upper_layer->parent;
				
				continue;
			}
			break;
		}
	}
	
	if(cur_db->size < DBSIZE / 2)	
	{
		if(j == cur_node->cur_num - 1)		//���data block��Ҷ�ӽڵ����ұߣ���������ֵܽ�һ��Ԫ��
		{
			sibling_db = (struct data_block_t *) cur_node->pointer[j - 1];
			
			if(sibling_db->size < DBSIZE / 2)	//���ֵܲ��㣬��ϲ�����data block
				merge_two_db(cur_node ,j - 1 ,j);
			else								//��������ֵܽ�һ��
				borrow_data_from_left(cur_node ,j - 1 ,cur_db ,sibling_db);
		}
		else
		{
			sibling_db = (struct data_block_t *) cur_node->pointer[j + 1];
		
			if(sibling_db->size < DBSIZE / 2)
				merge_two_db(cur_node ,j ,j + 1);
			else
				borrow_data_from_right(cur_node ,j + 1,cur_db ,sibling_db);
		}
	}
PASS_LEAF:	
	return 1;
}








