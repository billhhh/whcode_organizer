#include "bplustree.h"

void search_key(struct node_t * root ,int key)
{
	struct node_t * cur_node = root;
	
	while(!(cur_node->is_leaf))
	{
		int cnt = 0;
		
		while((key > cur_node->key[cnt]) && (cnt < cur_node->cur_num))
			cnt++;
		
		if(cnt == cur_node->cur_num)
		{
			printf("Search key %d failed,make sure key exists!\n",key);
			return;
		}
		
		cur_node = (struct node_t *) cur_node->pointer[cnt];
	}
	
	int index = 0;
	
	while((key > cur_node->key[index]) && (index < cur_node->cur_num))
		index++;
	
	if(index == cur_node->cur_num)
	{
		printf("Search key %d failed,make sure key exists!\n",key);
		return;
	}
	
	struct data_block_t * cur_db = (struct data_block_t *) cur_node->pointer[index];
	
	int pos = binary_search(cur_db->array ,cur_db->size ,key);
	
	if(cur_db->array[pos] == key)
	{
		printf("Key %d found!\n",key);
		return;
	}
	else
		printf("Key %d can not found,try other key!\n",key);
}
